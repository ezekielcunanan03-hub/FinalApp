class AuthService {
  static String? registeredEmail;
  static String? registeredPassword;
  static String? registeredName;

  static void registerUser({
    required String name,
    required String email,
    required String password,
  }) {
    registeredName = name;
    registeredEmail = email;
    registeredPassword = password;
  }

  static bool login({
    required String email,
    required String password,
  }) {
    return email == registeredEmail &&
        password == registeredPassword;
  }
}