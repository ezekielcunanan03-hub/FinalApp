// lib/screens/nutrition_screen.dart
import 'package:flutter/material.dart';

class NutritionScreen extends StatelessWidget {
  const NutritionScreen({super.key});

  Widget nutritionTile(String title, String value) {
    return Card(
      child: ListTile(
        title: Text(title),
        trailing: Text(value),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Nutrition Info')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Container(
              height: 200,
              width: double.infinity,
              decoration: BoxDecoration(
                color: Colors.green.shade100,
                borderRadius: BorderRadius.circular(20),
              ),
              child: const Icon(
                Icons.fastfood,
                size: 100,
                color: Colors.green,
              ),
            ),

            const SizedBox(height: 20),

            nutritionTile('Calories', '520 kcal'),
            nutritionTile('Protein', '30 g'),
            nutritionTile('Carbohydrates', '40 g'),
            nutritionTile('Fats', '18 g'),
            nutritionTile('Sugar', '10 g'),
          ],
        ),
      ),
    );
  }
}