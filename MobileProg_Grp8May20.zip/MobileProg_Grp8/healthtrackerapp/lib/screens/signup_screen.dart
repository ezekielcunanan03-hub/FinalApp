import 'package:flutter/material.dart';
import 'categories_screen.dart';
import 'login_screen.dart';

class SignUpScreen extends StatefulWidget {
  const SignUpScreen({super.key});

  @override
  State<SignUpScreen> createState() =>
      _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  final _formKey = GlobalKey<FormState>();

  final TextEditingController _nameController =
  TextEditingController();

  final TextEditingController _emailController =
  TextEditingController();

  final TextEditingController _passwordController =
  TextEditingController();

  final TextEditingController
  _confirmPasswordController =
  TextEditingController();

  bool _isLoading = false;
  bool _obscurePassword = true;
  bool _obscureConfirmPassword = true;

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    _confirmPasswordController.dispose();
    super.dispose();
  }

  void _submitSignUp() async {
    if (!_formKey.currentState!.validate())
      return;

    setState(() => _isLoading = true);

    await Future.delayed(
      const Duration(seconds: 1),
    );

    if (!mounted) return;

    setState(() => _isLoading = false);

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text(
          'Account created successfully',
        ),
      ),
    );

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder:
            (context) =>
        const CategoriesScreen(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Sign Up'),
      ),
      body: Center(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment:
                CrossAxisAlignment.stretch,
                children: [
                  Image.asset(
                    'assets/images/download1.jpg',
                    height: 160,
                  ),

                  const SizedBox(height: 30),

                  TextFormField(
                    controller: _nameController,
                    decoration:
                    const InputDecoration(
                      labelText: 'Full Name',
                      border:
                      OutlineInputBorder(),
                    ),
                    validator: (value) =>
                    (value == null ||
                        value
                            .trim()
                            .isEmpty)
                        ? 'Please enter your name'
                        : null,
                  ),

                  const SizedBox(height: 20),

                  TextFormField(
                    controller: _emailController,
                    keyboardType:
                    TextInputType
                        .emailAddress,
                    decoration:
                    const InputDecoration(
                      labelText: 'Email',
                      border:
                      OutlineInputBorder(),
                    ),
                    validator: (value) {
                      if (value == null ||
                          value.trim().isEmpty) {
                        return 'Please enter your email';
                      }

                      if (!RegExp(
                        r'^[^@]+@[^@]+\.[^@]+',
                      ).hasMatch(
                        value.trim(),
                      )) {
                        return 'Enter a valid email';
                      }

                      return null;
                    },
                  ),

                  const SizedBox(height: 20),

                  TextFormField(
                    controller:
                    _passwordController,
                    obscureText:
                    _obscurePassword,
                    decoration: InputDecoration(
                      labelText: 'Password',
                      border:
                      const OutlineInputBorder(),
                      suffixIcon: IconButton(
                        icon: Icon(
                          _obscurePassword
                              ? Icons.visibility
                              : Icons
                              .visibility_off,
                        ),
                        onPressed:
                            () => setState(
                              () =>
                          _obscurePassword =
                          !_obscurePassword,
                        ),
                      ),
                    ),
                    validator: (value) {
                      if (value == null ||
                          value.isEmpty)
                        return 'Please enter a password';

                      if (value.length < 6)
                        return 'Password must be at least 6 characters';

                      return null;
                    },
                  ),

                  const SizedBox(height: 20),

                  TextFormField(
                    controller:
                    _confirmPasswordController,
                    obscureText:
                    _obscureConfirmPassword,
                    decoration: InputDecoration(
                      labelText:
                      'Confirm Password',
                      border:
                      const OutlineInputBorder(),
                      suffixIcon: IconButton(
                        icon: Icon(
                          _obscureConfirmPassword
                              ? Icons.visibility
                              : Icons
                              .visibility_off,
                        ),
                        onPressed:
                            () => setState(
                              () =>
                          _obscureConfirmPassword =
                          !_obscureConfirmPassword,
                        ),
                      ),
                    ),
                    validator: (value) {
                      if (value == null ||
                          value.isEmpty)
                        return 'Please confirm password';

                      if (value !=
                          _passwordController
                              .text)
                        return 'Passwords do not match';

                      return null;
                    },
                  ),

                  const SizedBox(height: 30),

                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      minimumSize:
                      const Size(
                        double.infinity,
                        50,
                      ),
                    ),
                    onPressed:
                    _isLoading
                        ? null
                        : _submitSignUp,
                    child:
                    _isLoading
                        ? const SizedBox(
                      height: 22,
                      width: 22,
                      child:
                      CircularProgressIndicator(
                        strokeWidth: 2.5,
                        color:
                        Colors.white,
                      ),
                    )
                        : const Text(
                      'Create Account',
                    ),
                  ),

                  const SizedBox(height: 20),

                  Row(
                    mainAxisAlignment:
                    MainAxisAlignment.center,
                    children: [
                      const Text(
                        'Already have an account?',
                      ),
              TextButton(
                onPressed: () {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (context) =>
                      const LoginScreen(),
                    ),
                  );
                },
                child: const Text('Sign Up'),
              ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}